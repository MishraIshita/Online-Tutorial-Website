<html>
<head>
  <title>Main Page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <style>
 
  .panel {
    border: 1px solid 	#1295c9; 
    border-radius:0 !important;
    transition: box-shadow 0.5s;
  }
  .panel:hover {
    box-shadow: 5px 0px 40px rgba(0,0,0, .2);
  }
  .panel-footer .btn:hover {
    border: 1px solid 	#1295c9;
    background-color: #fff !important;
    color: 	#1295c9;
  }
  .panel-heading {
    color: #fff !important;
    background-color: 	#1295c9 !important;
    padding: 25px;
    border-bottom: 1px solid transparent;
    border-top-left-radius: 0px;
    border-top-right-radius: 0px;
    border-bottom-left-radius: 0px;
    border-bottom-right-radius: 0px;
  }
  .panel-footer {
    background-color: white !important;
  }
  .panel-footer h3 {
    font-size: 32px;
  }
  .panel-footer h4 {
    color: #aaa;
    font-size: 14px;
  }
  .panel-footer .btn {
    margin: 15px 0;
    background-color: 	#1295c9;
    color: #fff;
  }
  
  footer .glyphicon {
    font-size: 20px;
    margin-bottom: 20px;
    color: 	#1295c9;
 
  }
  </style>
</head>
<body>
    
<div id="portfolio" class="container-fluid text-center bg-grey">
  <h1>RESOURCES</h1><br>
  </div>
  
    <div class="container">
          <div class="row">
              <div class="col-sm-4">
                  <a href="cbook.php" class="thumbnail"><img  src="ebook.jpg"></a>
                   <div class="caption">
                           <center> <h2>EBOOKS</h2>
                           </center>
                        </div>

              </div>
              <div class="col-sm-4">
                  <a href="cvideo.php" class="thumbnail"><img  src="video.jpg"></a>
                  <div class="caption">
                      <center><h2>VIDEO LECTURES</h2>
                            <p></p></center>
                        </div>
              </div>
              <div class="col-sm-4">
                  <a href="home.php" class="thumbnail"><img  src="chatroom.jpg"></a>
                   <div class="caption">
                       <center><h2>CHATROOM</h2>
                          </center>
                        </div>
              </div>
              
          </div>
      </div>
    
  </body>
    
</html>