<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
session_start();
$con = mysqli_connect("localhost", "root", "", "software") or die(mysqli_error($con));
$msg = $_POST['msg'];
$email=$_SESSION['email'];
$user_registration_query = "insert into post(email,msg) values ('$email','$msg')";
$user_registration_submit = mysqli_query($con, $user_registration_query) or die(mysqli_error($con));

header('Location:home.php')

?>
