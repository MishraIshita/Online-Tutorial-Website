 <?php
session_start();
// put your code here
        ?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <!--jQuery library--> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!--Latest compiled and minified JavaScript--> 
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="style.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css" type="text/css"/>
    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css" type="text/css">

        <title>home</title>
        <style>
            .output{
                background-color: white;
                box-shadow: 0px 1px 1px #000;
                height: 250px;
                margin-bottom: 20px;
                overflow: scroll;
            }
        </style>
    </head>
    <body>
        <div id="main">
            <h1>
                
                <?php
               
                ?>
                ONLINE</h1>
        </div>
        <div class="output">
          <?php
                          include 'dbh.php';
          $sql='SELECT * FROM post';
          $result=  mysqli_query($conn, $sql);
if(mysqli_num_rows($result)!=0){
   while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){
       echo ''.$row['email'].' '.': :'.$row['msg'].' --'.$row['time'].'<br>';
       echo '<br>';
        
   }
    
}else{
   
   echo '0 results';
}
$conn->close();
          ?>
            
        </div>
        <form method="post" action="send.php">
            <div class="form-group">
                            <input type="text"  class="form-control" name="msg" id="msg" placeholder="type to send the message..">
                        </div>
             <input type="submit" value="Submit" class="btn btn-primary ">
        </form>
        <br><br><br><br><br><br><br><br><br>
         <form method="post" action="logout.php">
            
             <input type="submit" value="back" class="btn btn-primary ">
        </form>
        <?php
        // put your code here
        ?>
    </body>
</html>
