<?php
require 'dbh.php';
?>
<html>
    
<head>
        
<title>login</title>
        
<meta charset="UTF-8">
        
<meta name="viewport" content="width=device-width, initial-scale=1.0">
        
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    
<!--jQuery library--> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    
<!--Latest compiled and minified JavaScript--> 
    
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
<meta name="viewport" content="width=device-width, initial-scale=1">
    
<link href="style.css" rel="stylesheet" type="text/css">
    
<link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css" type="text/css"/>
    
<link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css" type="text/css">


    
</head>
    
<body>
        
<nav class="navbar navbar-inverse">
         
 <div class="container ">
             
 <div class="nav-headeer">
                 
     <a href="index.php" class="navbar-brand">HOME</a>
                 
 <div > 
                     
 <ul class="nav navbar-nav navbar-right">
                       
  <li>
                             
      <a href="signup.php"  ><span class="glyphicon glyphicon-user"> </span>  sign up</a>
                         
 </li>
  </ul>
                 
 </div>
            
  </div>
          
</div>
     
 </nav>
        
<br><br>
   
 <center>
        
        
<a><img src="logon.png" width="200" height="200"></a>     
  <br><br><br>
        
 <div class="container" >
            <div class="row">
                <div class="col-xs-4 col-md-offset-4">
                   
                    <form action="authenticate.php" method="post">
                        <div class="form-group">
                            <input type="email"  class="form-control" name="email"  placeholder="email" >
                        </div>
                        <div class="form-group">
                            <input type="text"  class="form-control" name="password" placeholder="password">
                        </div>
                        <input type="submit" value="Submit" class="btn btn-primary ">
                    </form>
                </div>
            </div>
        </div>
        
<br><br><br>       
     
 <div class="footer">Copyright @ 2COOL4SKOOL. All Rights Reserved and Contact Us: 01573 225 001</div>
    </center>
    
    
</body>

</html>
