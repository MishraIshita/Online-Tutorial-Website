<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require 'dbh.php';
$username = mysqli_real_escape_string($conn, $_POST['email']);
$password = mysqli_real_escape_string($conn, $_POST['password']);
$sql="SELECT email,password FROM users WHERE email='$username' AND password='$password' ";
$result=  mysqli_query($conn, $sql);
if(mysqli_num_rows($result)==0){
    echo 'nooooo';
}else{
    $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
   $_SESSION["email"]=$_POST['email'];
   echo $username;
   echo $password;
   echo $_SESSION['email'];
   header('Location:main.php');
}
?>