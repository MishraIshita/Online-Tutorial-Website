<html>
<title>R-Programming</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Lato", sans-serif}
.w3-bar,h1,button {font-family: "Montserrat", sans-serif}
.fa-anchor,.fa-coffee {font-size:200px}
</style>
<body>
<div class="w3-top">
<div class="w3-bar w3-blue w3-card w3-left-align w3-large">
<a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-hover-white w3-large w3-black" href="javascript:void(0);" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
<a href="#" class="w3-bar-item w3-button w3-padding-large w3-white">Home</a>
</div>
</div>
<header class="w3-container w3-blue w3-center" style="padding:128px 16px">
<h1 class="w3-margin w3-jumbo">R-PROGRAMMING</h1>
</header>
<div class="w3-row-padding w3-padding-64 w3-container">
<div class="w3-content">
<div class="w3-twothird">
<h3>
INTRODUCTION<br></h3>
<h4>
    <a href="r1.php" class="w3-bar-item w3-button w3-padding-large w3-white">Lecture 1: Types Of Variables</a><br>
    <a href="r2.php" class="w3-bar-item w3-button w3-padding-large w3-white">Lecture 2: Using Variables</a><br>
    <a href="r3.php" class="w3-bar-item w3-button w3-padding-large w3-white">Lecture 3: Logical Variables And Operators</a><br>
</h4><h3>
CONDITIONAL STATEMENTS<br></h3>

    <h4><a href="r4.php" class="w3-bar-item w3-button w3-padding-large w3-white">Lecture 4: The 'For' Loop</a><br>
        <a href="r5.php" class="w3-bar-item w3-button w3-padding-large w3-white">Lecture 5: The 'While' Loop</a><br>
        <a href="r6.php" class="w3-bar-item w3-button w3-padding-large w3-white">Lecture 6: The 'If' Statements</a><br>

</h4>
<h3>
FUNDAMENTALS OF R<br></h3>
    <h4><a href="r7.php" class="w3-bar-item w3-button w3-padding-large w3-white">Lecture 7: Vector</a><br>
        <a href="r8.php" class="w3-bar-item w3-button w3-padding-large w3-white">Lecture 8: Creating Vector</a><br>
        <a href="r9.php" class="w3-bar-item w3-button w3-padding-large w3-white">Lecture 9: Functions in R</a><br>

</h4>
<h3>
MATRICES<br></h3>
    <h4><a href="r10.php" class="w3-bar-item w3-button w3-padding-large w3-white">Lecture 10: Matrix</a><br>
        <a href="r11.php" class="w3-bar-item w3-button w3-padding-large w3-white">Lecture 11: Matrix Operations</a><br>

</h4>
<h3>
DATAFRAMES<br></h3>
    <h4><a href="r12.php" class="w3-bar-item w3-button w3-padding-large w3-white">Lecture 12: Importing Data into R </a><br>
    <a href="r13.php" class="w3-bar-item w3-button w3-padding-large w3-white">Lecture 13: Basic Operations with Dataframes</a><br>
    <a href="r14.php" class="w3-bar-item w3-button w3-padding-large w3-white">Lecture 14: Filtering a Dataframe</a><br>
    <a href="r15.php" class="w3-bar-item w3-button w3-padding-large w3-white">Lecture 15: Building a Dataframe</a><br>

</h4>
</div>
</div>
</div>
</body>
</html>
